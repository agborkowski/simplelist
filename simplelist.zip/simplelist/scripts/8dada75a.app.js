define([], function() {
  function ItemsModel(items) {
      this._items = items;

      this.added = new Event(this);
      this.removed = new Event(this);
  }

  ItemsModel.prototype = {
      get : function () {
          return [].concat(this._items);
      },

      add : function (item) {
          this._items.push(item);
          this.added.notify({ item : item });
      },

      remove : function (index) {
          var item;

          item = this._items[index];
          this._items.splice(index, 1);
          this.removed.notify({ item : item });
      }
  };

  function ItemsView(model, elements) {
      this._model = model;
      this._elements = elements;

      this.addButtonClicked = new Event(this);
      this.delButtonClicked = new Event(this);

      var _this = this;

      // attach model listeners
      this._model.added.attach(function () {
          _this.update();
      });
      this._model.removed.attach(function () {
          _this.update();
      });

      this._elements.addButton.click(function () {
          _this.addButtonClicked.notify();
          _this._elements.itemName.val('');

          return false;
      });

      this._elements.delButton.live('click', function () {
        _this.delButtonClicked.notify($(this).parent('li').data('id'));
      });
  }

  ItemsView.prototype = {
      show : function () {
          this.update();
      },

      update : function () {
          var list, items, index;

          list = this._elements.list;
          list.empty();

          items = this._model.get();
          for (index = 0; index < items.length; index += 1) {
              if (items.hasOwnProperty(index)) {
                  list.append($('<li data-id="' + index + '">' + items[index] + ' <button class="delete">delete</button></li>'));
              }
          }
      }
  };

  /**
   * The Controller. Controller responds to user actions and
   * invokes changes on the model.
   */
  function ItemsController(model, view) {
      this._model = model;
      this._view = view;

      var _this = this;

      this._view.addButtonClicked.attach(function () {
          _this.add();
      });

      this._view.delButtonClicked.attach(function (obj, index) {
          _this.remove(index);
      });
  }

  ItemsController.prototype = {
      add : function () {
          var item = this._view._elements.itemName.val();
          if (item) {
              this._model.add(item);
          }
      },

      remove : function (index) {
        this._model.remove(index);
      }
  };

  /**
   * Support for observer pattenr
   * @param {[type]} sender [description]
   */
  function Event(sender) {
    this._sender = sender;
    this._listeners = [];
  }

  Event.prototype = {
      attach : function (listener) {
          this._listeners.push(listener);
      },
      notify : function (args) {
          var index;

          for (index = 0; index < this._listeners.length; index += 1) {
              this._listeners[index](this._sender, args);
          }
      }
  };

  /**
   * App
   * @type {[type]}
   */
  var model = window.model = new ItemsModel(['PHP', 'JavaScript']),
  view = new ItemsView(model, {
      'list' : $('#items'),
      'itemName' : $('#item-name'),
      'addButton' : $('#item-add'),
      'delButton' : $('#items .delete')
  }),
  controller = new ItemsController(model, view);

  view.show();
});